# dependencies
backend/config
frontend/node_modules
backend/node_modules
socket/node_modules

npm-debug.log*
yarn-debug.log*
yarn-error.log*